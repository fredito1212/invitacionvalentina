<?php $__env->startSection('titulo'); ?>
    Fotografias de los invitados
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cardBotones'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('cardContenido'); ?>
    <div class="columns">
    <?php $__currentLoopData = $listado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if((($loop->index) % 3) == 0): ?>
    </div>
    <div class="columns">
        <?php endif; ?>
            <div class="column is-one-third">
                <a href="<?php echo url('fotos', ['codigo' => $l['codigo']]); ?>">
                    <div class="card">
                        <div class="card-image">
                            <figure class="image is-4by3">
                                <img src="<?php echo e($l['fotos'][0]->first()->archivo); ?>" height="auto" width="100%">
                            </figure>
                        </div>
                        <div class="card-content">
                            <div class="media">
                                <div class="media-content has-text-centered">
                                    <p class="title is-4"><?php echo e($l['nombre']); ?></p>
                                    <p class="subtitle is-6">
                                        <?php echo e($l['fotos']->count()); ?> <i class="fas fa-camera mr-6 has-text-link"></i>
                                        <?php echo e($l['pendientes']); ?> <i class="fas fa-clock has-text-info"></i>&nbsp;/&nbsp;
                                        <?php echo e($l['aceptadas']); ?> <i class="fas fa-check has-text-primary"></i>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </a>
            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('extraJS'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('base/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\desarrollo\appsLaravel\invitacionvalentina\resources\views/listadofotografias.blade.php ENDPATH**/ ?>