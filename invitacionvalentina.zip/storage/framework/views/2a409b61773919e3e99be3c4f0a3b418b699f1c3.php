<!-- Begin Tentang Sherly and Daeng -->
<section class="section-light regular-section is-fullheight" id="tentang-sherly-daeng">
    <div class="container">
      <div class="columns is-multiline">
      <div class="column has-text-centered is-12 prolog">
        <h1 class="title has-text-centered section-title" data-aos="fade-up" data-aos-easing="linear"><i class="fa-solid fa-heart fa-beat"></i> Mis fotos</h1>

        <div class="column is-12 regular-section" data-aos="fade-up" data-aos-easing="linear">
            <h1 class="title has-text-centered section-title">Proximamente</h1>
        </div>

    
      <!-- IMAGES -->
      <div class="space40px"></div>
        <div data-aos="fade-up" data-aos-easing="linear">
          <img src="image/divider-leaves.png" class="divider has-vertically-align" alt="~~~">
        </div>
        <div class="space40px"></div>
        <div class="space40px"></div>

      </div>
    </div>
  </section>
  <!-- End Tentang Sherly dan Daeng -->
<?php /**PATH D:\desarrollo\appsLaravel\invitacionvalentina\resources\views/fotos.blade.php ENDPATH**/ ?>