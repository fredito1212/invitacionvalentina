<?php $__env->startSection('titulo'); ?>
    Fotografias de <?php echo e($datos->nombre); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('cardBotones'); ?>
    <a href="<?php echo e(route('fotos')); ?>" class="button is-link"><i class="fas fa-reply"></i>&nbsp; Regresar</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('cardContenido'); ?>
    <div class="container has-text-centered">
        <h3><strong><?php echo e($fotos->count()); ?></strong> fotografia(s)</h3>
        <hr>
    </div>
    <div class="container">
        <div class="columns">
            <?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if((($loop->index) % 3) == 0): ?>
            </div>
            <div class="columns">
                <?php endif; ?>
                    <div class="column is-one-third">
                        <div class="card">
                            <a style="cursor:pointer;" onclick="actualizaImagen('<?php echo e($f->archivo); ?>');" class="js-modal-trigger" data-target="modal-foto">
                                <div class="card-image">
                                    <figure class="image is-4by3">
                                        <img src="<?php echo e($f->archivo); ?>" height="auto" width="100%">
                                    </figure>
                                </div>
                            </a>
                            <div class="card-content">
                                <div class="media">
                                    <div class="media-content has-text-centered">
                                        <p id="estado<?php echo e($f->id); ?>">
                                            <?php if($f->visible): ?>
                                                <i class="fas fa-check has-text-primary is-size-5"></i> Visible
                                            <?php else: ?>
                                                <i class="fas fa-clock has-text-info is-size-5"></i> Pendiente
                                            <?php endif; ?>
                                        </p>
                                        <hr>
                                        <div>
                                            <?php if($f->visible): ?>
                                                <a id="boton<?php echo e($f->id); ?>" onclick="actualizarFoto(<?php echo e($f->id); ?>, 0);" class="button is-warning mt-1">
                                                    <i class="fas fa-times"></i>&nbsp;Quitar
                                                </a>
                                            <?php else: ?>
                                                <a id="boton<?php echo e($f->id); ?>" onclick="actualizarFoto(<?php echo e($f->id); ?>, 1);" class="button is-success mt-1">
                                                    <i class="fas fa-check"></i>&nbsp;Mostrar
                                                </a>
                                            <?php endif; ?>
                                            <a onclick="borrarFoto(<?php echo e($f->id); ?>);"  class="button is-danger mt-1">
                                                <i class="fas fa-trash"></i>&nbsp;Borrar
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra'); ?>
<div class="modal" id="modal-foto">
    <div class="modal-background"></div>
    <div class="modal-content">
        <img id="fotoGrande" src="https://bulma.io/images/placeholders/1280x960.png" alt="">
    </div>
    <button class="modal-close is-large" aria-label="close"></button>
</div>


<form action="<?php echo e(route('fotos.borrarFoto')); ?>" method="post" id="formEliminar">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="idborrar" id="idborrar" value="">
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extraJS'); ?>
<script>
    <?php if(session()->has('success')): ?>
        Swal.fire({
            icon: 'success',
            title: 'Foto borrada correctamente!'
        });
    <?php endif; ?>

    document.addEventListener('DOMContentLoaded', () => {
        // Functions to open and close a modal
        function openModal($el) {
            $el.classList.add('is-active');
        }

        function closeModal($el) {
            $el.classList.remove('is-active');
        }

        function closeAllModals() {
            (document.querySelectorAll('.modal') || []).forEach(($modal) => {
            closeModal($modal);
            });
        }

        // Add a click event on buttons to open a specific modal
        (document.querySelectorAll('.js-modal-trigger') || []).forEach(($trigger) => {
            const modal = $trigger.dataset.target;
            const $target = document.getElementById(modal);

            $trigger.addEventListener('click', () => {
            openModal($target);
            });
        });

        // Add a click event on various child elements to close the parent modal
        (document.querySelectorAll('.modal-background, .modal-close, .modal-card-head .delete, .modal-card-foot .button') || []).forEach(($close) => {
            const $target = $close.closest('.modal');

            $close.addEventListener('click', () => {
            closeModal($target);
            });
        });

        // Add a keyboard event to close all modals
        document.addEventListener('keydown', (event) => {
            const e = event || window.event;

            if (e.keyCode === 27) { // Escape key
            closeAllModals();
            }
        });
    });

    function actualizaImagen(foto){
        $('#fotoGrande').attr('src', foto);
    }

    function actualizarFoto(id, estado){
        $.ajax({
            type: "POST",
            url: '<?php echo e(route('fotos.actualizarFoto')); ?>',
            data: {'id': id, 'estado': estado, '_token': "<?php echo e(csrf_token()); ?>"},
            success: function(data){
                if(data == true){
                    if(estado == 1){
                        $('#estado'+id).html('<i class="fas fa-check has-text-primary is-size-5"></i> Visible');
                        $('#boton'+id).removeClass('is-success').addClass('is-warning');
                        $('#boton'+id).html('<i class="fas fa-times"></i>&nbsp;Quitar');
                        $('#boton'+id).attr('onclick', 'actualizarFoto('+id+', 0);');
                        Swal.fire({
                            icon: 'success',
                            title: 'Foto aceptada correctamente!'
                        });
                    }else{
                        $('#estado'+id).html('<i class="fas fa-clock has-text-info is-size-5"></i> Pendiente');
                        $('#boton'+id).removeClass('is-warning').addClass('is-success');
                        $('#boton'+id).html('<i class="fas fa-check"></i>&nbsp;Mostrar');
                        $('#boton'+id).attr('onclick', 'actualizarFoto('+id+', 1);');
                        Swal.fire({
                            icon: 'success',
                            title: 'Foto ocultada correctamente!'
                        });
                    }
                }else{
                    Swal.fire({
                        icon: 'error',
                        title: 'Ocurrio un error!'
                    });
                }
            }
        });
    }

    function borrarFoto(id){
        Swal.fire({
            title: 'Estas seguro que desea borrar esta foto?',
            text: "Esta accion no se puede revertir",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Si, borrar esta foto'
        }).then((result) => {
            if(result.value === true){
                $('#idborrar').val(id);
                $('#formEliminar').submit();
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('base/base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\desarrollo\appsLaravel\invitacionvalentina\resources\views/listadofotoscodigo.blade.php ENDPATH**/ ?>