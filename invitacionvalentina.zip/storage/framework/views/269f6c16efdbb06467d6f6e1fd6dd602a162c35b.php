<!-- Begin Hero Menu -->
<div class="hero-foot ">
    <div class="hero-foot--wrapper">
      <div class="columns">
        <div class="column is-12 hero-menu-desktop has-text-centered">
          <ul>
            <li class="is-active">
              <a href="#home"><i class="fa-solid fa-envelope fa-bounce"></i> Invitación</a>
            </li>
            <li>
              <a href="#Waktu"><i class="fa-solid fa-calendar-day fa-flip" style="--fa-animation-duration: 3s;"></i> Fecha</a>
            </li>
            <li>
              <a href="#lokasi"><i class="fa-solid fa-location-dot fa-shake"></i> Ubicación</a>
            </li>
            <li>
              <a href="#tentang-sherly-daeng"><i class="fa-solid fa-heart fa-beat"></i> Mis fotos</a>
            </li>

            <li>
              <a href="#rsvp"><i class="fa-solid fa-check-double fa-fade"></i> Asistencia</a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <!-- End Hero Menu -->
<?php /**PATH D:\desarrollo\appsLaravel\invitacionvalentina\resources\views/hero-menu.blade.php ENDPATH**/ ?>