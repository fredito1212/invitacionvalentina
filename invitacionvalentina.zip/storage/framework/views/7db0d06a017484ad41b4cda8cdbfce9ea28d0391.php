<!-- Begin RSVP Content -->
<section class="section-dark contact" id="rsvp">
    <div class="container">
      <div class="columns is-multiline">
        <div class="column is-12 prolog">
          <h1 class="title has-text-centered section-title" data-aos="fade-up" data-aos-easing="linear"><i class="fa-solid fa-check-double fa-fade"></i> Asistencia</h1>
        </div>
        <div class="column is-12 prolog has-text-centered" data-aos="fade-up" data-aos-easing="linear">
          <p class="h2 subtitle">
            Es un honor y una felicidad para nosotros
            <br>
            que aceptes la invitación a está ceremonia tan importante
            <br>
            <br>
            Si pudieras asistir esperamos tu confirmación
            <br>
            <br>
            Si no es posible asistir a nuestra celebración, está bien,
            <br>
            esperamos verte muy pronto
            <br>
            <br>
            Información:
            <br>En la celebración, proporcionaremos desinfectante para manos
            <br>y controles de temperatura corporal.
            </p>
          <div class="space40px"></div>

          <div class="space40px"></div>
          <div data-aos="fade-up" data-aos-easing="linear">
            <img src="image/divider-leaves.png" class="divider has-text-centered" alt="~~~">
          </div>
          <div class="space40px"></div>
          <p class="h2 subtitle" data-aos="fade-up" data-aos-easing="linear">
            Familia Bravo Andrade
          </p>

        </div>

     </div>
    </div>
  </section>

<?php /**PATH D:\desarrollo\appsLaravel\invitacionvalentina\resources\views/asistencia.blade.php ENDPATH**/ ?>