# Pendientes de implementar en sitio
- Falta el archivo invitacion.png en la carpeta public/image/
- banner de elotes ale y bsmorelia
- agregar un boton para volver arriba

# Caracteristicas
- modal para cargar fotos automaticamente de invitados del evento
- carrusel de fotos del evento
- Modal de confirmación de asistencia
- Visualización de fotos invitados y aceptación al portal

valentina
vale
fhUe*B_nXT1HQDip
