# Pendientes de implementar en sitio
- Falta el archivo invitacion.png en la carpeta public/image/
- banner de elotes ale y bsmorelia
- agregar pattern.css y modificar algunos bloques
- cambiar foto del banner principal
- agregar un boton para volver arriba
- checar vista movil

# Caracteristicas
- modal para cargar fotos automaticamente de invitados del evento
- carrusel de fotos del evento
- Lista de invitados
  - Agregar invitados
    - Nombre
    - Telefono WA
    - Acompañantes
    - Codigo unico
    - Estado de invitación
  - Envíar invitación por WA
  - Descargar invitación
- Modal de confirmación de asistencia
- Visualización de fotos invitados y aceptación al portal
