<!-- Begin RSVP Content -->
<section class="section-dark has-background-danger" id="rsvp">
    <div class="container">
      <div class="columns is-multiline">
        <div class="column is-12 prolog">
          <h1 class="title has-text-centered section-title" data-aos="fade-up" data-aos-easing="linear" style="color: white !important;"><i class="fa-solid fa-check-double fa-fade"></i> Asistencia</h1>
        </div>
        <div class="column is-12 prolog has-text-centered" data-aos="fade-up" data-aos-easing="linear">
          <h1 class="title has-text-centered section-title" style="color: white !important;">ESTA INVITACIÓN NO ES VALIDA</h1>
        </div>

     </div>
    </div>
  </section>
<!-- End RSVP Content -->
